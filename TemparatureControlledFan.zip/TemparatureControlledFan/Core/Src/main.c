/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : DHT11 Fan Controller - MOTOR FIX VERSION
  ******************************************************************************
  * MOTOR CONTROL FIX:
  * 1. Proper L298N control (IN1, IN2, ENA)
  * 2. Initial PWM set to HIGH
  * 3. Direction control added
  * 4. Motor diagnostic added
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include <stdio.h>
#include <string.h>

/* Private typedef -----------------------------------------------------------*/
typedef struct {
    uint8_t temperature;
    uint8_t humidity;
    uint8_t temp_decimal;
    uint8_t hum_decimal;
    uint8_t checksum;
} DHT11_Data;

/* Private define ------------------------------------------------------------*/
#define LCD_ADDR (0x27 << 1)  // Try 0x3F if 0x27 doesn't work

#define DHT11_PIN GPIO_PIN_1
#define DHT11_PORT GPIOA

// L298N Motor Control Pins
// IMPORTANT: Update these based on YOUR actual pin configuration!
#define MOTOR_IN1_PIN motor_Pin        // Direction pin 1
#define MOTOR_IN1_PORT motor_GPIO_Port
// If you have IN2 pin, uncomment and configure:
// #define MOTOR_IN2_PIN GPIO_PIN_X
// #define MOTOR_IN2_PORT GPIOx
// ENA pin is TIM4_CH1 (PWM) - configured in CubeMX

// Temperature thresholds
#define TEMP_OFF      25
#define TEMP_SLOW     30
#define TEMP_MEDIUM   35

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim4;

DHT11_Data dht11_data;
uint8_t fan_speed = 0;

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM4_Init(void);

// DHT11 Functions
void DHT11_SetPinOutput(void);
void DHT11_SetPinInput(void);
uint8_t DHT11_Start(void);
uint8_t DHT11_Read(DHT11_Data *data);

// LCD Functions
void LCD_SendCmd(uint8_t cmd);
void LCD_SendData(uint8_t data);
void LCD_Init(void);
void LCD_Clear(void);
void LCD_SetCursor(uint8_t row, uint8_t col);
void LCD_PrintString(char *str);

// Motor Control
void Motor_Init(void);
void Motor_SetSpeed(uint8_t speed);
void Motor_Stop(void);
void Motor_Test(void);

// Delay
void delay_us(uint32_t us);

/* Private user code ---------------------------------------------------------*/

/**
  * @brief  Microsecond delay using TIM2
  */
void delay_us(uint32_t us)
{
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    while(__HAL_TIM_GET_COUNTER(&htim2) < us);
}

/**
  * @brief  Set DHT11 pin as output
  */
void DHT11_SetPinOutput(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DHT11_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);
}

/**
  * @brief  Set DHT11 pin as input with pull-up
  */
void DHT11_SetPinInput(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DHT11_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);
}

/**
  * @brief  Send start signal and check DHT11 response
  */
uint8_t DHT11_Start(void)
{
    uint32_t timeout = 0;

    DHT11_SetPinOutput();
    HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_RESET);
    HAL_Delay(18);

    HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_SET);
    delay_us(20);
    DHT11_SetPinInput();

    timeout = 0;
    while(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_SET)
    {
        timeout++;
        if(timeout > 100) return 0;
        delay_us(1);
    }

    timeout = 0;
    while(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_RESET)
    {
        timeout++;
        if(timeout > 100) return 0;
        delay_us(1);
    }

    timeout = 0;
    while(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_SET)
    {
        timeout++;
        if(timeout > 100) return 0;
        delay_us(1);
    }

    return 1;
}

/**
  * @brief  Read one byte from DHT11
  */
uint8_t DHT11_ReadByte(void)
{
    uint8_t byte = 0;
    uint32_t timeout;

    for(int i = 0; i < 8; i++)
    {
        timeout = 0;
        while(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_RESET)
        {
            timeout++;
            if(timeout > 100) return 0;
            delay_us(1);
        }

        delay_us(40);

        if(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_SET)
        {
            byte |= (1 << (7 - i));

            timeout = 0;
            while(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN) == GPIO_PIN_SET)
            {
                timeout++;
                if(timeout > 100) return byte;
                delay_us(1);
            }
        }
    }

    return byte;
}

/**
  * @brief  Read temperature and humidity from DHT11
  */
uint8_t DHT11_Read(DHT11_Data *data)
{
    uint8_t hum_int, hum_dec, temp_int, temp_dec, checksum;

    if(!DHT11_Start())
    {
        return 0;
    }

    hum_int = DHT11_ReadByte();
    hum_dec = DHT11_ReadByte();
    temp_int = DHT11_ReadByte();
    temp_dec = DHT11_ReadByte();
    checksum = DHT11_ReadByte();

    uint8_t calculated_checksum = hum_int + hum_dec + temp_int + temp_dec;

    if(checksum != calculated_checksum)
    {
        return 0;
    }

    if(temp_int > 50 || hum_int < 20 || hum_int > 90)
    {
        return 0;
    }

    data->humidity = hum_int;
    data->temperature = temp_int;
    data->hum_decimal = hum_dec;
    data->temp_decimal = temp_dec;
    data->checksum = checksum;

    return 1;
}

/* ===========================================================================
 * LCD FUNCTIONS
 * ===========================================================================
 */

void LCD_SendCmd(uint8_t cmd)
{
    uint8_t data_u, data_l;
    uint8_t data_t[4];

    data_u = (cmd & 0xF0);
    data_l = ((cmd << 4) & 0xF0);

    data_t[0] = data_u | 0x0C;
    data_t[1] = data_u | 0x08;
    data_t[2] = data_l | 0x0C;
    data_t[3] = data_l | 0x08;

    HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, data_t, 4, 100);
}

void LCD_SendData(uint8_t data)
{
    uint8_t data_u, data_l;
    uint8_t data_t[4];

    data_u = (data & 0xF0);
    data_l = ((data << 4) & 0xF0);

    data_t[0] = data_u | 0x0D;
    data_t[1] = data_u | 0x09;
    data_t[2] = data_l | 0x0D;
    data_t[3] = data_l | 0x09;

    HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, data_t, 4, 100);
}

void LCD_Init(void)
{
    HAL_Delay(50);
    LCD_SendCmd(0x30);
    HAL_Delay(5);
    LCD_SendCmd(0x30);
    HAL_Delay(1);
    LCD_SendCmd(0x30);
    HAL_Delay(10);
    LCD_SendCmd(0x20);
    HAL_Delay(10);

    LCD_SendCmd(0x28);
    HAL_Delay(1);
    LCD_SendCmd(0x08);
    HAL_Delay(1);
    LCD_SendCmd(0x01);
    HAL_Delay(2);
    LCD_SendCmd(0x06);
    HAL_Delay(1);
    LCD_SendCmd(0x0C);
}

void LCD_Clear(void)
{
    LCD_SendCmd(0x01);
    HAL_Delay(2);
}

void LCD_SetCursor(uint8_t row, uint8_t col)
{
    uint8_t position = (row == 0) ? (0x80 + col) : (0xC0 + col);
    LCD_SendCmd(position);
}

void LCD_PrintString(char *str)
{
    while(*str)
    {
        LCD_SendData(*str++);
    }
}

/* ===========================================================================
 * MOTOR CONTROL - L298N DRIVER
 * ===========================================================================
 */

/**
  * @brief  Initialize motor control
  * @note   For L298N:
  *         - IN1 = HIGH, IN2 = LOW → Motor rotates forward
  *         - IN1 = LOW, IN2 = HIGH → Motor rotates reverse
  *         - ENA (PWM) controls speed
  */
void Motor_Init(void)
{
    // Set direction pins
    HAL_GPIO_WritePin(MOTOR_IN1_PORT, MOTOR_IN1_PIN, GPIO_PIN_SET);  // Forward

    // If you have IN2 connected, uncomment this:
    // HAL_GPIO_WritePin(MOTOR_IN2_PORT, MOTOR_IN2_PIN, GPIO_PIN_RESET);

    // Start with motor stopped
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0);
}

/**
  * @brief  Set motor speed (0-100%)
  * @param  speed: Speed percentage (0-100)
  */
void Motor_SetSpeed(uint8_t speed)
{
    if(speed == 0)
    {
        Motor_Stop();
        return;
    }

    if(speed > 100) speed = 100;

    // Set direction for forward rotation
    HAL_GPIO_WritePin(MOTOR_IN1_PORT, MOTOR_IN1_PIN, GPIO_PIN_SET);

    // If you have IN2, uncomment this:
    // HAL_GPIO_WritePin(MOTOR_IN2_PORT, MOTOR_IN2_PIN, GPIO_PIN_RESET);

    // Calculate PWM duty cycle
    uint32_t pulse = (speed * (htim4.Init.Period + 1)) / 100;
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, pulse);
}

/**
  * @brief  Stop motor
  */
void Motor_Stop(void)
{
    // Stop PWM
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0);

    // Optional: Set both IN pins LOW to brake
    // HAL_GPIO_WritePin(MOTOR_IN1_PORT, MOTOR_IN1_PIN, GPIO_PIN_RESET);
    // HAL_GPIO_WritePin(MOTOR_IN2_PORT, MOTOR_IN2_PIN, GPIO_PIN_RESET);
}

/**
  * @brief  Test motor at different speeds
  */
void Motor_Test(void)
{
    LCD_Clear();
    LCD_SetCursor(0, 0);
    LCD_PrintString("Motor Test");
    HAL_Delay(1000);

    // Test 30% speed
    LCD_SetCursor(1, 0);
    LCD_PrintString("Speed: 30%");
    Motor_SetSpeed(30);
    HAL_Delay(2000);

    // Test 60% speed
    LCD_SetCursor(1, 0);
    LCD_PrintString("Speed: 60%");
    Motor_SetSpeed(60);
    HAL_Delay(2000);

    // Test 100% speed
    LCD_SetCursor(1, 0);
    LCD_PrintString("Speed: 100%");
    Motor_SetSpeed(100);
    HAL_Delay(2000);

    // Stop
    LCD_SetCursor(1, 0);
    LCD_PrintString("Speed: 0%  ");
    Motor_Stop();
    HAL_Delay(1000);
}

/* ===========================================================================
 * MAIN PROGRAM
 * ===========================================================================
 */

int main(void)
{
    char lcd_buffer[17];
    uint8_t read_success = 0;
    uint8_t error_count = 0;
    uint8_t retry_count = 0;

    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_TIM2_Init();
    MX_TIM4_Init();

    /* Start timers */
    HAL_TIM_Base_Start(&htim2);
    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);

    /* Initialize LCD */
    HAL_Delay(100);
    LCD_Init();
    LCD_Clear();

    /* Initialize Motor */
    Motor_Init();

    /* Welcome message */
    LCD_SetCursor(0, 0);
    LCD_PrintString("DHT11 Fan Ctrl");
    LCD_SetCursor(1, 0);
    LCD_PrintString("Initializing...");
    HAL_Delay(2000);

    /* MOTOR TEST - Comment out after testing */
    Motor_Test();  // Remove this line after confirming motor works

    /* Wait for DHT11 to stabilize */
    LCD_Clear();
    LCD_SetCursor(0, 0);
    LCD_PrintString("Waiting DHT11...");
    HAL_Delay(2000);

    /* Infinite loop */
    while(1)
    {
        retry_count = 0;
        read_success = 0;

        // Try reading sensor
        while(retry_count < 3 && !read_success)
        {
            read_success = DHT11_Read(&dht11_data);
            if(!read_success)
            {
                retry_count++;
                HAL_Delay(100);
            }
        }

        if(read_success)
        {
            error_count = 0;

            uint8_t temp = dht11_data.temperature;
            uint8_t humidity = dht11_data.humidity;

            /* Fan control logic */
            if(temp < TEMP_OFF)
            {
                fan_speed = 0;
                Motor_Stop();
            }
            else if(temp >= TEMP_OFF && temp < TEMP_SLOW)
            {
                fan_speed = 40;
                Motor_SetSpeed(fan_speed);
            }
            else if(temp >= TEMP_SLOW && temp < TEMP_MEDIUM)
            {
                fan_speed = 70;
                Motor_SetSpeed(fan_speed);
            }
            else
            {
                fan_speed = 100;
                Motor_SetSpeed(fan_speed);
            }

            /* Display on LCD */
            LCD_SetCursor(0, 0);
            sprintf(lcd_buffer, "T:%02dC H:%02d%%    ", temp, humidity);
            LCD_PrintString(lcd_buffer);

            LCD_SetCursor(1, 0);
            sprintf(lcd_buffer, "Fan: %3d%%     ", fan_speed);
            LCD_PrintString(lcd_buffer);
        }
        else
        {
            error_count++;

            LCD_SetCursor(0, 0);
            LCD_PrintString("DHT11 ERROR!   ");

            LCD_SetCursor(1, 0);
            if(error_count < 5)
            {
                sprintf(lcd_buffer, "Retry: %d/5    ", error_count);
                LCD_PrintString(lcd_buffer);
            }
            else
            {
                LCD_PrintString("Check wiring!  ");
                Motor_Stop();
            }
        }

        HAL_Delay(2500);
    }
}

/* ===========================================================================
 * PERIPHERAL INITIALIZATION
 * ===========================================================================
 */

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
    RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
    if(HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if(HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_I2C1_Init(void)
{
    hi2c1.Instance = I2C1;
    hi2c1.Init.ClockSpeed = 100000;
    hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
    hi2c1.Init.OwnAddress1 = 0;
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2 = 0;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
    if(HAL_I2C_Init(&hi2c1) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_TIM2_Init(void)
{
    TIM_ClockConfigTypeDef sClockSourceConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig = {0};

    htim2.Instance = TIM2;
    htim2.Init.Prescaler = 63;
    htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim2.Init.Period = 0xFFFF;
    htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if(HAL_TIM_Base_Init(&htim2) != HAL_OK)
    {
        Error_Handler();
    }
    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
    if(HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
    {
        Error_Handler();
    }
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if(HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_TIM4_Init(void)
{
    TIM_ClockConfigTypeDef sClockSourceConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig = {0};
    TIM_OC_InitTypeDef sConfigOC = {0};

    htim4.Instance = TIM4;
    htim4.Init.Prescaler = 63;
    htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim4.Init.Period = 999;
    htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if(HAL_TIM_Base_Init(&htim4) != HAL_OK)
    {
        Error_Handler();
    }
    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
    if(HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
    {
        Error_Handler();
    }
    if(HAL_TIM_PWM_Init(&htim4) != HAL_OK)
    {
        Error_Handler();
    }
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if(HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
    {
        Error_Handler();
    }
    sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = 0;
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
    if(HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
    {
        Error_Handler();
    }
    HAL_TIM_MspPostInit(&htim4);
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor_GPIO_Port, motor_Pin, GPIO_PIN_RESET);

    GPIO_InitStruct.Pin = GPIO_PIN_1;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = motor_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(motor_GPIO_Port, &GPIO_InitStruct);
}

void Error_Handler(void)
{
    __disable_irq();
    while(1)
    {
    }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif
